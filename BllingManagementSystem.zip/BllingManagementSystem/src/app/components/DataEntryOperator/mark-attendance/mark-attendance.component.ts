import { Component, OnInit } from '@angular/core';
import { AdminService } from '../../Administrator/admin.service';
import { FormGroup, FormBuilder } from '@angular/forms';
import { DataEntryOperator } from '../DataEntryOperator';
import { HttpClient } from '@angular/common/http';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
@Component({
  selector: 'app-mark-attendance',
  templateUrl: './mark-attendance.component.html',
  styleUrls: ['./mark-attendance.component.css']
})
export class MarkAttendanceComponent implements OnInit {

  constructor(private sb: MatSnackBar,private admin : AdminService,private fb: FormBuilder,private _http:HttpClient,private router : Router) { }
  readonly APP_URL = 'http://localhost:8022/BillingManagementSystem';
  x:any;
  developer : any;
  devForm : FormGroup;
  deo : DataEntryOperator;
  userid : any;
  halfDay:any;
  fullDay:any;
  enteredYear:any;
  months=[
    {id:"January",name :"January"},
    {id : "Febuary",name :"Febuary"},
    {id : "March",name :"March"},
    {id : "April",name :"April"},
    {id : "May",name :"May"},
    {id : "June",name :"June"},
    {id : "July",name :"July"},
    {id : "August",name :"August"},
    {id : "Saptember",name :"Saptember"},
    {id : "October",name :"October"},
    {id : "November",name :"November"},
    {id : "December",name :"December"},
  ];
  ngOnInit() {
    this.userid=localStorage.getItem("userid");
    if(this.userid==='')
    {
        this.router.navigate(['/']);
    }
    this.devForm = this.fb.group({
      "devId":[''],
      "month":[''],
      "year":[''],
      "halfDay":[''],
      "fullDay":['']
    });
    this.admin. getDevelopers()
      .subscribe(data => {this.developer=data;console.log(this.developer)},
      //console.log(this.project),
      error => {
        console.log('Error ocurred',error); 
      }
      );
  }
  onClick()
  {
    console.log("elseif"+(new Date().getFullYear));
    this.halfDay=this.devForm.value.halfDay;
    this.fullDay=this.devForm.value.fullDay;
    this.enteredYear=this.devForm.value.year;
    if((this.halfDay+this.fullDay )>30)
    {
      this.sb.open("Number of half and full can't be more than 30.!",undefined,{
        duration:5000,
      })
    }
    else if(((new Date()).getFullYear()<this.enteredYear) )
    {
      console.log("elseif"+(new Date()).getFullYear);
      
      this.sb.open("Attendance for future can't be mark!",undefined,{
        duration:5000,
      })
    }

    else{
      console.log(this.devForm.value);
      this.deo=this.devForm.value;
      this.devForm.reset();
      
      console.log('Inside Component');
      console.log(this.deo);
      this._http.post(this.APP_URL+'/submitAttendance',this.deo)
      .subscribe(data => {this.x=data;console.log(this.x),
        this.sb.open("Attendance Added Sucessfully.!",undefined,{
        duration:2000,
      })
    },
        //console.log(this.project),
        error => {
          this.sb.open("Developer attendance is already marked !",undefined,{
            duration:5000,
          })
          console.log('Error ocurred',error);
    }
  );
  }
  }
call()
{
  localStorage.setItem("userid",'');
  this.userid=localStorage.getItem("userid");
  //this.router.navigate(['/admin'])
}
}
