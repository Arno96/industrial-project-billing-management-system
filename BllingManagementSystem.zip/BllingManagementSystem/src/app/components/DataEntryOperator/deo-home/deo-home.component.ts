import { Component, OnInit } from '@angular/core';
import { PlatformLocation } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'app-deo-home',
  templateUrl: './deo-home.component.html',
  styleUrls: ['./deo-home.component.css']
})
export class DeoHomeComponent implements OnInit {

  constructor(private location : PlatformLocation,private router : Router) { 
    location.onPopState(()=>{
      history.forward();
    })
  }
  userid:any;
  ngOnInit() {
    this.userid=localStorage.getItem("userid");
    if(this.userid==='')
    {
        this.router.navigate(['/']);
    }
  }
  call()
  {
    localStorage.setItem("userid",'');
    this.userid=localStorage.getItem("userid");
    //this.router.navigate(['/admin'])
  }
}
