export class DataEntryOperator
{
    month:String;
    year:number;
    halfDay:number;
    fullDay:number;
    devId:number;

    constructor(month,year,halfDay,fullDay,devId)
    {
        this.month=month;
        this.year=year;
        this.halfDay=halfDay;
        this.fullDay=fullDay;
        this.devId=devId;
    }
}