import { Component, OnInit } from '@angular/core';
import { FormGroup,FormBuilder,Validators} from '@angular/forms'
import { Developer } from 'src/app/Developer';
import {LoginServiceService} from '../../login-service.service';
import {Router}  from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
@Component({
  selector: 'app-log-in',
  templateUrl: './log-in.component.html',
  styleUrls: ['./log-in.component.css']
})
export class LogInComponent implements OnInit {

  developer : Developer;
  developers : Developer[];
  developerList : any;
  developer1 : any;
  role: any;
  profileForm:FormGroup;
  constructor(private router: Router, private login : FormBuilder, private login_service: LoginServiceService) { }

 
  ngOnInit() {
    this.profileForm = this.login.group({
      'developerId': ['', Validators.required],
      'password': ['', [Validators.required]]
    })
  }
  x : any;
  onSubmit(){
    this.developer = this.profileForm.value;  
    //console.warn(this.developer);
    this.developer1 = this.login_service.validate(this.developer)
    .subscribe((data)=>{
      this.developer=data
      this.x = this.developer
      this.afterSubmit();
    },
    // error=>{
    //   //console.log(error.message);
    //   ()=>{console.log("data fetched"),alert("Incorrect Credentials");}
      (err: any) => {
      if (err instanceof HttpErrorResponse) {
        if (err.status === 401) {
         alert("Invalid Credentials !!")
        }
        else{
          this.afterSubmit();
        }
        
      }
    })
  }
  afterSubmit(){
    localStorage.setItem("userid", this.x.developerName);
    
    this.role = this.x.role;
    if(this.role==="Admin"){
      this.router.navigate(['/admin'])
    }
    else if(this.role==="DEO")
    {
      this.router.navigate(['/DEO'])
    }
    else
    {
      alert("Incorrect Credentials");
    }
  }
  logOut()
    {
    localStorage.setItem("userid", null);
   }
 
}
