export class DeveloperRole
{
    roleId : number;
    roleName : number;
}