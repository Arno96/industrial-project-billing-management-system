import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PlatformLocation } from '@angular/common';

@Component({
  selector: 'app-admin-dash-board',
  templateUrl: './admin-dash-board.component.html',
  styleUrls: ['./admin-dash-board.component.css']
})
export class AdminDashBoardComponent implements OnInit {

  constructor(private router : Router,private location : PlatformLocation) {
    location.onPopState(()=>{
      history.forward();
    })
   }

  ngOnInit() {
    this.userid=localStorage.getItem("userid");
    if(this.userid==='')
    {
        this.router.navigate(['/']);
    }
  }
  

  userid : string;
   call()
   {
     localStorage.setItem("userid",'');
     this.userid=localStorage.getItem("userid");
     //this.router.navigate(['/admin'])
   }
}
