import { Component, OnInit } from '@angular/core';
import { AdminService } from '../admin.service';
import { Developer } from 'src/app/Developer';
import { FormBuilder , FormGroup, NgForm } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';
@Component({
  selector: 'app-developer-billing',
  templateUrl: './developer-billing.component.html',
  styleUrls: ['./developer-billing.component.css']
})
export class DeveloperBillingComponent implements OnInit {

  constructor(private sb: MatSnackBar,private admin : AdminService, private fb: FormBuilder,private _http : HttpClient,private router : Router) { }
  developer1:Developer;
  developer : any;
  x : any;
  id: any;
  month : any;
  year:any;
  a=false
  userid : any;
  enteredYear:any;
  months=[
    {id:"January",name :"January"},
    {id : "Febuary",name :"Febuary"},
    {id : "March",name :"March"},
    {id : "April",name :"April"},
    {id : "May",name :"May"},
    {id : "June",name :"June"},
    {id : "July",name :"July"},
    {id : "August",name :"August"},
    {id : "Saptember",name :"Saptember"},
    {id : "October",name :"October"},
    {id : "November",name :"November"},
    {id : "December",name :"December"},
  ];

  ngOnInit() {
    this.userid=localStorage.getItem("userid");
    if(this.userid==='')
    {
        this.router.navigate(['/']);
    }
    this.admin.getDevelopers()
        .subscribe(data => {this.developer=data;console.warn(this.developer)
          this.x = this.developer;
          //console.log(this.x)
          //console.warn("this is developers:"+this.developer);
        },
      error => console.log('Error ocurred',error)); 
    }

  onSubmit(form : NgForm){

    this.id = form.value.devName;
    this.month = form.value.month;
    this.year = form.value.year;

    if(((new Date()).getFullYear()<this.year) )
    {
      this.sb.open("Billing  for future can't be done!",undefined,{
        duration:5000,
      })
    }
    
    else{
      form.reset();
      console.log(this.id)
      console.log(this.month)
      console.log(this.year)
      this.admin.getDeveloperBilling(this.id,this.month,this.year)
      .subscribe(data => {this.x=data;console.log("asdhgkgsad"+this.x),this.a=true},
          //console.log(this.project),
          error => {
            this.sb.open("Developer is not allocated yet..!",undefined,{
              duration:3000,
            })
            console.log('Error ocurred',error); 
          }
          );
          //this.a=true;
    }
  }
  call()
  {
    localStorage.setItem("userid",'');
    this.userid=localStorage.getItem("userid");
    //this.router.navigate(['/admin'])
  }
}
