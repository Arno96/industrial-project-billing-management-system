import { Component, OnInit } from '@angular/core';
import { AdminService } from '../admin.service';
import { FormBuilder, FormGroup } from '@angular/forms';
import { DevAllocation } from '../DevAllocation';
import { HttpClient } from '@angular/common/http';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
@Component({
  selector: 'app-developer-allocation',
  templateUrl: './developer-allocation.component.html',
  styleUrls: ['./developer-allocation.component.css']
})
export class DeveloperAllocationComponent implements OnInit {
  readonly APP_URL = 'http://localhost:8022/BillingManagementSystem';
  constructor(private router : Router,private sb: MatSnackBar,private fb: FormBuilder,private admin : AdminService,private _http:HttpClient) { }
  developer:any;
  devAllocation:DevAllocation;
  proj:any;
  x:any;
  devForm : FormGroup;
  userid:any;
  ngOnInit() {
    this.userid=localStorage.getItem("userid");
    if(this.userid==='')
    {
        this.router.navigate(['/']);
    }
    this.devForm = this.fb.group({
      "developerId":[''],
      "configId":['']
    });
    this.admin.getDeveloperNotAllocated()
    .subscribe(data => {this.developer=data;console.log(this.developer)},
      //console.log(this.project),
      error => {
        console.log('Error ocurred',error); 
      }
      );
      this.admin.getProjectConfiguration()
    .subscribe(data => {this.proj=data;console.log(this.proj)},
      //console.log(this.project),
      error => {
        console.log('Error ocurred',error); 
      }
      );
  }
  onClick()
  {
    this.sb.open("Developer Allocated Sucessfully.!",undefined,{
      duration:1500,
    })


    console.log(this.devForm.value);
  this.devAllocation=this.devForm.value;
  this.devForm.reset();
  console.log('Inside Component');
  console.log(this.devAllocation);
  this._http.post(this.APP_URL+'/addDevAllocate',this.devAllocation)
  .subscribe(data => {this.x=data;console.log(this.x)},
    //console.log(this.project),
    error => {
      console.log('Error ocurred',error); 
    }
    );
  }
  call()
  {
    localStorage.setItem("userid",'');
    this.userid=localStorage.getItem("userid");
    //this.router.navigate(['/admin'])
  }
}
