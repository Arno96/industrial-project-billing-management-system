import { Injectable } from '@angular/core';
import { Project } from './Project';
import { HttpClient } from '@angular/common/http';
import { DeveloperRole} from './DeveloperRole';
import {Developer} from '../../Developer';  
import { ProjectConfig } from './ProjectConfig';

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  readonly APP_URL = 'http://localhost:8022/BillingManagementSystem';
  constructor(private _http : HttpClient) { }

    getProjects()
    {
      return this._http.get<Project[]>(this.APP_URL + '/getProjects');
    }
    getRoles()
    {
      return this._http.get<DeveloperRole[]>(this.APP_URL + '/getRoles');
    }
    getDevelopers()
    {
      return this._http.get<Developer[]>(this.APP_URL+'/getDevelopers');
    }
    getDeveloperNotAllocated()
    {
      return this._http.get<Developer[]>(this.APP_URL+'/getFilteredDevelopers');
    }
    getProjectConfiguration()
    {
      return this._http.get<ProjectConfig[]>(this.APP_URL+'/getAllProjectConfig');
    }
    getDeveloperBilling(id,month,year)
    {
      return this._http.get(this.APP_URL+'/developerBilling/'+id+'/'+month+'/'+year);
    }
    getProjectBilling(id,month,year)
    {
      return this._http.get(this.APP_URL+'/projectBilling/'+id+'/'+month+'/'+year);
    }
    deleteUser(id)
    {
      return this._http.delete(this.APP_URL+'/DeleteProjConfig/' + id);
    }
    ProjectConfigById(id){
      return this._http.get(this.APP_URL+'/getProjectConfigById/'+ id);
    }
    updateProjectConfig(projectConfig)
    {
      return this._http.put(this.APP_URL + '/updateProjectConfigById',projectConfig);
    }
}
