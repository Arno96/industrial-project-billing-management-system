export class DevAllocation
{
    allocationId:number;
    configId : number;
    devId : number;
}