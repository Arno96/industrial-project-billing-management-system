import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';

import { ProjectConfigComponent } from '../project-config/project-config.component';
import {MatSnackBarModule} from '@angular/material';
import {DeveloperBillingComponent} from '../developer-billing/developer-billing.component';
import { ProjectBillingComponent } from '../project-billing/project-billing.component';
import { DeveloperAllocationComponent } from '../developer-allocation/developer-allocation.component';


export const RoutesTable : Routes =[
  { path :'admin/projectConfig', component : ProjectConfigComponent},
  { path :'admin/developerAllocation', component : DeveloperAllocationComponent},
  { path : 'admin/developerBilling', component : DeveloperBillingComponent},
  { path : 'admin/projectBilling', component :ProjectBillingComponent},
    // { path :'**',component : AdminWelcomeComponent},
  // { path :'adminHomePage', component :AdminHomePageComponent}
];

@NgModule({
  declarations: [],
  imports: [
    CommonModule,MatSnackBarModule,RouterModule.forRoot(RoutesTable),
    // RouterModule.forRoot(
    //   [
    //     {path : 'admin' , component : AdminDashBoardComponent},
    //    // {path : 'project-config' ,  component : ProjectConfigComponent},
    //     { path :'projectConfig', component : ProjectConfigComponent},
    //     // { path :'projectAllocation', component : ProjectAllocationComponent},
    //     // { path : 'developerBilling', component : DeveloperBillingComponent},
    //     // { path : 'projectBilling', component :ProjectBillingComponent},
    //     // { path :'**',component : AdminHomePageComponent},
    //     // { path :'adminHomePage', component :AdminHomePageComponent}
    //  ]
    // )
  ],
  exports: [RouterModule]
})
export class AdminModuleModule { }
