import { Component, OnInit } from '@angular/core';
import { AdminService } from '../admin.service';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-project-billing',
  templateUrl: './project-billing.component.html',
  styleUrls: ['./project-billing.component.css']
})
export class ProjectBillingComponent implements OnInit {

  constructor(private sb: MatSnackBar,private admin : AdminService,private router : Router) { }
  project : any;
  x : any;
  id :any;
  month : any;
  a:any;
  year : any;
  userid:any;
  months=[
    {id:"January",name :"January"},
    {id : "Febuary",name :"Febuary"},
    {id : "March",name :"March"},
    {id : "April",name :"April"},
    {id : "May",name :"May"},
    {id : "June",name :"June"},
    {id : "July",name :"July"},
    {id : "August",name :"August"},
    {id : "Saptember",name :"Saptember"},
    {id : "October",name :"October"},
    {id : "November",name :"November"},
    {id : "December",name :"December"},
  ];
  ngOnInit() {
    this.userid=localStorage.getItem("userid");
   
    if(this.userid==='')
    {
        this.router.navigate(['/']);
    }
    this.admin.getProjects()
        .subscribe(data => {this.project=data;console.warn(this.project)
          this.x = this.project;
        },
      error => console.log('Error ocurred',error)); 
  }
  onSubmit(form : NgForm){
    this.year = form.value.year;  
    if(((new Date()).getFullYear()<this.year) )
    {
      this.sb.open("Billing  for future can't be done!",undefined,{
        duration:5000,
      })
    }
    else
    {
      this.id = form.value.proName;
      this.month = form.value.month;
      
      form.reset();
      console.log(this.id)
      console.log(this.month)
      console.log(this.year)
      this.admin.getProjectBilling(this.id,this.month,this.year)
      .subscribe(data => {this.x=data;console.log(this.x)},
          //console.log(this.project),
          error => {
            console.log('Error ocurred',error); 
          }
          );
          this.a=true;
     }
  }
  call()
  {
    localStorage.setItem("userid",'');
    this.userid=localStorage.getItem("userid");
    //this.router.navigate(['/admin'])
  }
}
