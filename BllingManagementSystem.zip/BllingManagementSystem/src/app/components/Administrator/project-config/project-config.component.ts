import { Component, OnInit,Injectable } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import {FormBuilder, FormGroup, FormControl, Validator,ReactiveFormsModule, FormsModule, Validators  } from '@angular/forms';
import { Project } from '../Project';
import { HttpClient } from '@angular/common/http';
import { DeveloperRole } from '../DeveloperRole';
import { AdminService } from '../admin.service';
import { ProjectConfig } from '../ProjectConfig';
import { Router } from '@angular/router';
import { filter } from 'rxjs/operators';

@Component({
  selector: 'app-project-config',
  templateUrl: './project-config.component.html',
  styleUrls: ['./project-config.component.css']
})
export class ProjectConfigComponent implements OnInit {
  readonly APP_URL = 'http://localhost:8022/BillingManagementSystem';
  //stem_field = ['Deep Learning', 'Reinforcement Learning', 'Evolutionary Algorithms', 'Genetic Algorithms'];
  fetched=false;
  project : any;
  role : any;
  add=false;
  pcObj : any;
  x:any;
  isupdated = false;
  constructor(private sb: MatSnackBar,private fb: FormBuilder,private _http : HttpClient,
    private admin : AdminService,private router : Router,private fb1: FormBuilder ) {}
  projForm : FormGroup;

  projectConfigUpdateForm = this.fb1.group({
  "projectId":['',Validators.required],
  "roleId":['',Validators.required],  
  "location":['',Validators.required],
  "perHourBilling":['', Validators.min(1)]
  });
  
  pconfig:ProjectConfig;
  userid : any;
  ngOnInit()
  {
    this.userid=localStorage.getItem("userid");
    if(this.userid==='')
    {
        this.router.navigate(['/']);
    }
    this.projForm = this.fb.group({
      "projectId":['',Validators.required],
      "roleId":['',Validators.required],
      "location":['',Validators.required],
      "perHourBilling":['', Validators.min(1)]
    });

    
  this.admin.getProjects()
    .subscribe(data => {this.project=data;console.log(this.project)},
    error => {
    console.log('Error ocurred',error); 
    }
  );

  this.admin.getRoles()
  .subscribe(data => {this.role=data;console.log(this.role)},
    error => {
      console.log('Error ocurred',error); 
    }
    );

    this.admin.getProjectConfiguration()
  .subscribe(data => {this.pcObj=data;console.log(this.pcObj)},
    error => {
      console.log('Error ocurred',error); 
    }
    );   
  }  
 
  onClick()
  {
    
    this.add=false;
    console.log(this.projForm.value);
  this.pconfig=this.projForm.value;
  this.projForm.reset();
  console.log("this is "  + this.pconfig.projectId);
  this._http.post(this.APP_URL+'/submitProjectConfig',this.pconfig)
  .subscribe(data => {
    this.x=data;console.log(this.x)
    this.admin.getProjectConfiguration()
    .subscribe(data => {this.pcObj=data;console.log(this.pcObj),
      this.sb.open("Project Configuration Added Sucessfully.!",undefined,{
      duration:2000,
    })
  },
      error => {
        console.log('Error ocurred asdsdds',error); 
      }
      );
  },
    error => {
      this.sb.open("Project is already Allocated.!",undefined,{
        duration:1500,})
      console.log('Error ocurred 1111',error); 
    }
    );
  }
  onAdd()
  {
    this.add=true;
  }
  call()
  {
    localStorage.setItem("userid",'');
    this.userid=localStorage.getItem("userid");
    //this.router.navigate(['/admin'])
  }

  response : any
  deleteUser(id): void {
    this.admin.deleteUser(id)
    .subscribe(data => {this.response=data;
      
      
      /**/if(!this.response)
      {
        this.sb.open("Project Configuration can't be Deleted.!",undefined,{
          duration:3000,
        })
      }
      else
      {
        console.log("sahgfd"+this.response)
        this.admin.getProjectConfiguration()
        .subscribe(data => {this.pcObj=data;console.log("i am her "+this.pcObj),
        this.sb.open("Project Configuration  Deleted.!",undefined,{
          duration:3000,
        })},
          error => {
            this.sb.open("Respone Errored.!",undefined,{
              duration:2000,})
            console.log('Error ocurred responsee',error); 
              })
      }
    }, 
    error => {
      this.sb.open("Developer can't be deleted.!",undefined,{
        duration:2000,})

      console.log('Error ocurred errorrr',error); 
    }
    );
  }
  
  projList:any;

  projectConfigById(id): void{
    this.admin.ProjectConfigById(id)
    .subscribe(data => {
      console.log(data);
      this.projList=data;
      this.fetched=true;
    },
    error => console.log(error));
  }
};


// console.warn(proj)
// this.admin.deleteUser(proj)
// .subscribe(data=> {
//   this.response = this.response.filter(u => u !== proj);


