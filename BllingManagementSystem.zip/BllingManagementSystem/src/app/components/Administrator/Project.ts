export class Project
{
    projectId : number;
    projectName : string;
    description : string;
    active : string;
}