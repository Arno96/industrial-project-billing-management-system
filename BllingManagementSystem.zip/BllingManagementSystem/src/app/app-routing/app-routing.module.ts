import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { LogInComponent } from '../components/log-in/log-in.component';
import { RegisterComponent } from '../components/register/register.component';
import {HomeComponent} from '../home/home.component';
import {AdminModuleModule} from '../components/Administrator/admin-module/admin-module.module';

import { ProjectConfigComponent } from '../components/Administrator/project-config/project-config.component';
import { AdminDashBoardComponent } from '../components/Administrator/admin-dash-board/admin-dash-board.component';
import { DeoHomeComponent } from '../components/DataEntryOperator/deo-home/deo-home.component';
import { MarkAttendanceComponent } from '../components/DataEntryOperator/mark-attendance/mark-attendance.component';
import { PageNotFoundComponent } from '../page-not-found/page-not-found.component';


const routes: Routes = [
  { path: '', component:HomeComponent },
  { path: 'login', component: LogInComponent },
  { path: 'register', component: RegisterComponent },
  {path : 'admin' , component : AdminDashBoardComponent},
  {path : 'DEO', component : DeoHomeComponent},
   {path:'DEO/mark', component: MarkAttendanceComponent},
  {path : '**' ,  component : PageNotFoundComponent}
];
@NgModule({
  declarations: [],
  imports: [
    CommonModule,AdminModuleModule,
    RouterModule.forRoot(routes,
        { enableTracing: true}
      )
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
