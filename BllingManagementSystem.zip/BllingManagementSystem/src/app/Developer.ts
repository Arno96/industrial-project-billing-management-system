export class Developer
{
    developerId :  number;
    developerName : string;
    gender : string;
    contactNo : string;
    email : string;
    role : string;
    password : string;
}