import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Developer } from './Developer';
import { catchError,map } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class LoginServiceService {
  developer : Developer;
  constructor(private _http: HttpClient){}
  readonly APP_URL = 'http://localhost:8022/BillingManagementSystem';
  myresponse: any;
  public validate(developer) {
    console.log(developer)
    return this._http.post<Developer>(this.APP_URL + "/validateRole", developer);
  }
}
