import { BrowserModule } from '@angular/platform-browser';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { AppComponent } from './app.component';
import { LogInComponent } from './components/log-in/log-in.component';
import { RegisterComponent } from './components/register/register.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AngularMaterialModule } from './angular-material/angular-material.module';
import { FlexLayoutModule} from '@angular/flex-layout';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing/app-routing.module';
import { HttpClientModule } from '@angular/common/http';

import { HomeComponent } from './home/home.component';
import {ProjectConfigComponent} from './components/Administrator/project-config/project-config.component';
import { DeveloperBillingComponent } from './components/Administrator/developer-billing/developer-billing.component';
import { AdminDashBoardComponent } from './components/Administrator/admin-dash-board/admin-dash-board.component';
import { ProjectBillingComponent } from './components/Administrator/project-billing/project-billing.component';
import { DeveloperAllocationComponent } from './components/Administrator/developer-allocation/developer-allocation.component';
import { DeoHomeComponent } from './components/DataEntryOperator/deo-home/deo-home.component';
import { MarkAttendanceComponent } from './components/DataEntryOperator/mark-attendance/mark-attendance.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';



@NgModule({
  declarations: [
    AppComponent,
    LogInComponent,
    RegisterComponent,
    
    HomeComponent,
    ProjectConfigComponent,
    DeveloperBillingComponent,
    AdminDashBoardComponent,
    ProjectBillingComponent,
    DeveloperAllocationComponent,
    DeoHomeComponent,
    MarkAttendanceComponent,
    PageNotFoundComponent
  ],
  imports: [
    AngularMaterialModule,
    BrowserModule,
    BrowserAnimationsModule,
    FlexLayoutModule,
    FormsModule, 
    ReactiveFormsModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class AppModule { }