package com.iris.get19.pbms.dao;

import java.util.List;

import com.iris.get19.pbms.dao.model.DataEntryOperator;
import com.iris.get19.pbms.dao.model.DevAllocation;
import com.iris.get19.pbms.dao.model.Developer;
import com.iris.get19.pbms.dao.model.ProjectConfiguration;

import java.util.List;



public interface DeveloperDao {
	public boolean setDevAllocate(DevAllocation devObj);
	public List<Developer> getAllDeveloper();
	public boolean setAttendance(DataEntryOperator deoObj);
	public DataEntryOperator getDeoObj(int id, String month, int year);
	public List<Developer> getFilteredDeveloper();
	public Developer getdeveloperById(int devId);
	
	
	
}
