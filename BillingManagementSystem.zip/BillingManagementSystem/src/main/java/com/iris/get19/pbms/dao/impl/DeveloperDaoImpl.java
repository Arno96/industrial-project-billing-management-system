package com.iris.get19.pbms.dao.impl;


import java.util.List;

//import java.util.List;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.event.internal.DefaultPersistOnFlushEventListener;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.iris.get19.pbms.dao.DeveloperDao;
import com.iris.get19.pbms.dao.model.DataEntryOperator;
import com.iris.get19.pbms.dao.model.DevAllocation;
import com.iris.get19.pbms.dao.model.Developer;
import com.iris.get19.pbms.dao.model.DeveloperRole;
import com.iris.get19.pbms.dao.model.ProjectConfiguration;

@Component
@Repository(value="developerDao")
@Transactional
public class DeveloperDaoImpl implements DeveloperDao {

	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public boolean setDevAllocate(DevAllocation devObj) {
		try
		{
			Session session=sessionFactory.getCurrentSession();
			session.save(devObj);
			return true;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public List<Developer> getAllDeveloper() {
		try
		{
			Session session=sessionFactory.getCurrentSession();
			Query q = session.createQuery("from Developer where role=:x");
			q.setParameter("x","Developer");
			return q.list();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public boolean setAttendance(DataEntryOperator deoObj) {
		try
		{
			Session session=sessionFactory.getCurrentSession();
			session.save(deoObj);
			return true;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public DataEntryOperator getDeoObj(int id, String month, int year) {
		try
		{
			Session session=sessionFactory.getCurrentSession();
			Query q = session.createQuery("from DataEntryOperator where devid=:x and month=:y and year=:z ");
			q.setParameter("x", id);
			q.setParameter("y", month);
			q.setParameter("z",year);
			return (DataEntryOperator) q.getResultList().get(0);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<Developer> getFilteredDeveloper() {
		try {
			Session session=sessionFactory.getCurrentSession(); 
			Query q=session.createQuery("from Developer where developerId not in(select dObj.developerId from DevAllocation) and role=:x ");
			q.setParameter("x","Developer");
			return q.list();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Developer getdeveloperById(int devId) {
		try
		{
			Session session = sessionFactory.getCurrentSession();
			Developer q = session.get(Developer.class,devId);
			return q;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return null;
	}
	                                                                                              
	

	

	
}
