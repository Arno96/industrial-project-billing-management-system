package com.iris.get19.pbms.dao;

import java.util.List;

import com.iris.get19.pbms.dao.model.DevAllocation;
import com.iris.get19.pbms.dao.model.Developer;
import com.iris.get19.pbms.dao.model.Project;
import com.iris.get19.pbms.dao.model.ProjectConfiguration;

public interface ProjectDao {

	Developer getDeveloper(Developer dev);

	boolean setProjectConfig(ProjectConfiguration projObj);

	List<Project> getAllProjects();

	List<ProjectConfiguration> getAllProjectConfig();

	DevAllocation getConfig(int id);

	DevAllocation getDevAlObj(int id);

	List<ProjectConfiguration> getAllConfigId(int id);

	Project getProjectById(int id);

	DevAllocation getDevAlObjByConfigId(int cid);

	List<ProjectConfiguration> getAllConfigIds(int id);

	List<DevAllocation> getDevAllocation();

	List<DevAllocation> getDevAlObjByConfigIdList(int cid);

	ProjectConfiguration getProjectConfigById(int configId);

	boolean delProjectConfig(int id);

	ProjectConfiguration getProjectConfig(int id);

	boolean updateProjectConfig(ProjectConfiguration projObj);

}
