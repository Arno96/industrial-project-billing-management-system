package com.iris.get19.pbms.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.iris.get19.pbms.dao.DeveloperDao;
import com.iris.get19.pbms.dao.ProjectDao;
import com.iris.get19.pbms.dao.RoleDao;
import com.iris.get19.pbms.dao.model.DevAllocation;
import com.iris.get19.pbms.dao.model.Developer;
import com.iris.get19.pbms.dao.model.DeveloperRole;
import com.iris.get19.pbms.dao.model.Project;
import com.iris.get19.pbms.dao.model.ProjectConfiguration;
import com.iris.get19.pbms.service.AdminService;

@RestController
public class AdminController {
	
	@Autowired
	private AdminService adminService;
	
	@Autowired
	HttpSession session;
	
	@Autowired
	RoleDao roleDao;
	
	@Autowired
	DeveloperDao developerDao;
	
	@Autowired
	ProjectDao projectDao;
	
	@CrossOrigin(origins="http://localhost:4200")
	@RequestMapping(value= "/submitProjectConfig",method=RequestMethod.POST)
	public boolean submitConfig(@RequestBody ProjectConfiguration projObj) {
		

		
		projObj.setRoleObj(roleDao.getRoleById(projObj.getRoleId()));
		projObj.setProjectObj(projectDao.getProjectById(projObj.getProjectId()));
		
		/*if(checkSession(map)) {
			return new ModelAndView("login");
		}*/
		
		
		boolean saved = adminService.setProjectConfig(projObj);
		return saved;
	}
	
	@CrossOrigin(origins="http://localhost:4200")
	@RequestMapping(value= "/getProjects",method=RequestMethod.GET)
	public ResponseEntity<List<Project>> getAllProject() {
		
		/*if(checkSession(map)) {
			return new ModelAndView("login");
		}*/
		return new ResponseEntity<List<Project>>(adminService.getAllProjects(),HttpStatus.OK);
	}
	
	@CrossOrigin(origins="http://localhost:4200")
	@RequestMapping(value= "/getRoles",method=RequestMethod.GET)
	public ResponseEntity<List<DeveloperRole>> getAllRole() {
		
		/*if(checkSession(map)) {
			return new ModelAndView("login");
		}*/
		return new ResponseEntity<List<DeveloperRole>>(adminService.getAllRoles(),HttpStatus.OK);
	}
	@CrossOrigin(origins="http://localhost:4200")
	@RequestMapping(value= "/addDevAllocate",method=RequestMethod.POST)
	public boolean devAllocate(@RequestBody DevAllocation devObj) {
		
		System.out.println("config Id : "+devObj.getConfigId());
		System.out.println("developer Id : "+devObj.getDeveloperId());
		
		devObj.setdObj(developerDao.getdeveloperById(devObj.getDeveloperId()));
		devObj.setPcObj(projectDao.getProjectConfigById(devObj.getConfigId()));
		boolean saved=adminService.setDevAllocate(devObj);
		return saved;
	}
	
	@CrossOrigin(origins="http://localhost:4200")
	@RequestMapping(value= "/getDevelopers",method=RequestMethod.GET)
	public ResponseEntity<List<Developer>> getAllDeveloper() {
		
		return new ResponseEntity<List<Developer>>(adminService.getAllDevelopers(),HttpStatus.OK);
	}
	
	@CrossOrigin(origins="http://localhost:4200")
	@RequestMapping(value= "/getFilteredDevelopers",method=RequestMethod.GET)
	public ResponseEntity<List<Developer>> getFilterDeveloper() {
		
		return new ResponseEntity<List<Developer>>(adminService.getFilterDevelopers(),HttpStatus.OK);
	}
	
	@CrossOrigin(origins="http://localhost:4200")
	@RequestMapping(value= "/getAllProjectConfig",method=RequestMethod.GET)
	public ResponseEntity<List<ProjectConfiguration>> getAllProjectConfig() {
		
		return new ResponseEntity<List<ProjectConfiguration>>(adminService.getAllProjectConfig(),HttpStatus.OK);
	}
	
	@CrossOrigin(origins="http://localhost:4200")							
	@RequestMapping(value= "/developerBilling/{id}/{month}/{year}", method= RequestMethod.GET)
	public double developerBilling(@PathVariable int id,@PathVariable String month,@PathVariable int year)
	{	
		double bill=adminService.getBill(id,month,year);
		return bill;
	}
	
	@CrossOrigin(origins="http://localhost:4200")							
	@RequestMapping(value= "/projectBilling/{id}/{month}/{year}", method= RequestMethod.GET)
	public double projectBilling(@PathVariable int id,@PathVariable String month,@PathVariable int year)
	{	
		double bill=adminService.getProjBill(id,month,year);
		return bill;
	}
	
	@CrossOrigin(origins="http://localhost:4200")							
	@RequestMapping(value= "/DevAllocation", method= RequestMethod.GET)
	public ResponseEntity<List<DevAllocation>> getAllDeveloperAllocationList()
	{
		return new ResponseEntity<List<DevAllocation>>(adminService.getDevAllocation(),HttpStatus.OK);
	}

	@CrossOrigin(origins="http://localhost:4200")							
	@RequestMapping(value= "/DeleteProjConfig/{id}", method= RequestMethod.DELETE)
	public boolean delProjConfig(@PathVariable int id)
	{
		System.out.println("Im in Delete Project Config "+id);
		return adminService.delProjConfig(id);
	}	
	
	@CrossOrigin(origins="http://localhost:4200")							
	@RequestMapping(value= "/getProjectConfigById/{id}", method= RequestMethod.GET)
	public ProjectConfiguration getProjConfigById(@PathVariable int id)	
	{
		return adminService.getProjectConfig(id);
	}
			
	@CrossOrigin(origins="http://localhost:4200")							
	@RequestMapping(value= "/updateProjectConfigById", method= RequestMethod.PUT)
	public boolean updateProjConfig(@RequestBody ProjectConfiguration projObj)
	{
		projObj.setRoleObj(roleDao.getRoleById(projObj.getRoleId()));
		projObj.setProjectObj(projectDao.getProjectById(projObj.getProjectId()));
		boolean saved = adminService.updateProjectConfig(projObj);
		return saved;
	}
}
