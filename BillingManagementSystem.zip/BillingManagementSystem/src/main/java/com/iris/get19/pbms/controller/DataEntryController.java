package com.iris.get19.pbms.controller;




import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.iris.get19.pbms.dao.DeveloperDao;
import com.iris.get19.pbms.dao.model.DataEntryOperator;
import com.iris.get19.pbms.dao.model.Developer;
import com.iris.get19.pbms.dao.model.ProjectConfiguration;
import com.iris.get19.pbms.service.DataEntryService;

@RestController
public class DataEntryController {
	
	@Autowired
	private DataEntryService dataEntryService;
	
	@Autowired
	private DeveloperDao developerDao;

	@Autowired
	HttpSession session;
	
	@CrossOrigin(origins="http://localhost:4200")
	@RequestMapping(value= "/submitAttendance",method=RequestMethod.POST)
	public boolean submitDevAttendance(@RequestBody DataEntryOperator deoObj) {
		
		deoObj.setDevObj(developerDao.getdeveloperById(deoObj.getDevId()));
		boolean saved = dataEntryService.setDevAttendance(deoObj);
		return saved;
	}
	

}
