package com.iris.get19.pbms.service;

import java.util.List;

import com.iris.get19.pbms.dao.model.DataEntryOperator;
import com.iris.get19.pbms.dao.model.DevAllocation;
import com.iris.get19.pbms.dao.model.Developer;
import com.iris.get19.pbms.dao.model.DeveloperRole;
import com.iris.get19.pbms.dao.model.Project;
import com.iris.get19.pbms.dao.model.ProjectConfiguration;


public interface AdminService {

	Developer getDeveloper(Developer dev);
	boolean setProjectConfig(ProjectConfiguration projObj);
	List<Project> getAllProjects();
	List<DeveloperRole> getAllRoles();
	boolean setDevAllocate(DevAllocation devObj);
	List<Developer> getAllDevelopers();
	List<ProjectConfiguration> getAllProjectConfig();
	double getBill(int id, String month, int year);
	double getProjBill(int id, String month, int year);
	List<ProjectConfiguration> getAllConfigId(int id);
	String getProjectName(int id);
	List<DevAllocation> getDevAllocation();

	List<Developer> getFilterDevelopers();
	boolean delProjConfig(int id);
	ProjectConfiguration getProjectConfig(int id);
	boolean updateProjectConfig(ProjectConfiguration projObj);
	
			
}
