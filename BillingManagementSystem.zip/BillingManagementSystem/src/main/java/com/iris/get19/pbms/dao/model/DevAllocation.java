package com.iris.get19.pbms.dao.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="DevAllocation")
public class DevAllocation {
	@Id
	@GeneratedValue
	@Column(name="id")
	private int allocationId;
	
	@OneToOne
	@JoinColumn(name="configid")
	ProjectConfiguration pcObj;
	
	@OneToOne
	@JoinColumn(name="devid")
	Developer dObj;
	
	@Transient
	private int configId;
	
	@Transient 
	private int developerId;

	public int getAllocationId() {
		return allocationId;
	}

	public void setAllocationId(int allocationId) {
		this.allocationId = allocationId;
	}

	public ProjectConfiguration getPcObj() {
		return pcObj;
	}

	public void setPcObj(ProjectConfiguration pcObj) {
		this.pcObj = pcObj;
	}

	public Developer getdObj() {
		return dObj;
	}

	public void setdObj(Developer dObj) {
		this.dObj = dObj;
	}

	public int getConfigId() {
		return configId;
	}

	public void setConfigId(int configId) {
		this.configId = configId;
	}

	public int getDeveloperId() {
		return developerId;
	}

	public void setDeveloperId(int developerId) {
		this.developerId = developerId;
	}
	

	
	
	
	
}
