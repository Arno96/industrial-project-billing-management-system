package com.iris.get19.pbms.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.iris.get19.pbms.dao.DeveloperDao;
import com.iris.get19.pbms.dao.ProjectDao;
import com.iris.get19.pbms.dao.model.DataEntryOperator;
import com.iris.get19.pbms.dao.model.DevAllocation;
import com.iris.get19.pbms.dao.model.Developer;
import com.iris.get19.pbms.dao.model.DeveloperRole;
import com.iris.get19.pbms.dao.model.Project;
import com.iris.get19.pbms.dao.model.ProjectConfiguration;
import com.iris.get19.pbms.service.AdminService;
import com.iris.get19.pbms.dao.RoleDao;

// TODO: Auto-generated Javadoc
/**
 * The Class AdminServiceImpl.
 */
@Component
@Repository(value = "adminService")
@Transactional
public class AdminServiceImpl implements AdminService {

	/** The project dao. */
	@Autowired
	private ProjectDao projectDao;
	
	/** The role dao. */
	@Autowired
	private RoleDao roleDao;
	
	/** The developer dao. */
	@Autowired
	private DeveloperDao developerDao;

	/* (non-Javadoc)
	 * @see com.iris.get19.pbms.service.AdminService#getDeveloper(com.iris.get19.pbms.dao.model.Developer)
	 */
	@Override
	public Developer getDeveloper(Developer dev) {
		return projectDao.getDeveloper(dev);
	}

	/* (non-Javadoc)
	 * @see com.iris.get19.pbms.service.AdminService#setProjectConfig(com.iris.get19.pbms.dao.model.ProjectConfiguration)
	 */
	@Override
	public boolean setProjectConfig(ProjectConfiguration projObj) {
		return projectDao.setProjectConfig(projObj);
	}

	/* (non-Javadoc)
	 * @see com.iris.get19.pbms.service.AdminService#getAllProjects()
	 */
	@Override
	public List<Project> getAllProjects() {
		return projectDao.getAllProjects();
	}

	/* (non-Javadoc)
	 * @see com.iris.get19.pbms.service.AdminService#getAllRoles()
	 */
	@Override
	public List<DeveloperRole> getAllRoles() {
		return roleDao.getAllRole();
	}

	/* (non-Javadoc)
	 * @see com.iris.get19.pbms.service.AdminService#setDevAllocate(com.iris.get19.pbms.dao.model.DevAllocation)
	 */
	@Override
	public boolean setDevAllocate(DevAllocation devObj) {
		return developerDao.setDevAllocate(devObj);
	}

	/* (non-Javadoc)
	 * @see com.iris.get19.pbms.service.AdminService#getAllDevelopers()
	 */
	@Override
	public List<Developer> getAllDevelopers() {
		return developerDao.getAllDeveloper();
	}

	/* (non-Javadoc)
	 * @see com.iris.get19.pbms.service.AdminService#getBill(int, java.lang.String, int)
	 */
	@Override
	public double getBill(int id, String month, int year) {
		DevAllocation devObj = projectDao.getDevAlObj(id);
		double perHourBilling = devObj.getPcObj().getPerHourBilling();
		// String name = developerDao.getDeveloperById(developerId);
		// map.addAttribute("name", name);
		DataEntryOperator deo = developerDao.getDeoObj(id, month, year);
		System.out.println(deo.getFullDay());
		return (deo.getFullDay() * 9 + deo.getHalfDay() * 4.5) * perHourBilling;
		
	}

	/* (non-Javadoc)
	 * @see com.iris.get19.pbms.service.AdminService#getAllProjectConfig()
	 */
	@Override
	public List<ProjectConfiguration> getAllProjectConfig() {
		return projectDao.getAllProjectConfig();
	}

	/* (non-Javadoc)
	 * @see com.iris.get19.pbms.service.AdminService#getAllConfigId(int)
	 */
	@Override
	public List<ProjectConfiguration> getAllConfigId(int id) {
		return projectDao.getAllConfigId(id);
	}

	/* (non-Javadoc)
	 * @see com.iris.get19.pbms.service.AdminService#getProjectName(int)
	 */
	@Override
	public String getProjectName(int id) {
		Project p = projectDao.getProjectById(id);
		System.out.println(p);
		String name = p.getProjectName();
		return name;
	}

	/* (non-Javadoc)
	 * @see com.iris.get19.pbms.service.AdminService#getProjBill(int, java.lang.String, int)
	 */
	@Override
	public double getProjBill(int id, String month, int year) {
		try {
			System.out.println(id + month);
			double bill = 0;
			List<ProjectConfiguration> projConfigList = projectDao.getAllConfigIds(id);

			int count = 0;
			for (ProjectConfiguration configObj : projConfigList) {
				int cid = configObj.getConfigurationId();
				System.out.println(cid);
				System.out.println("inside loop");
				List<DevAllocation> devList = projectDao.getDevAlObjByConfigIdList(cid);
				for (DevAllocation devObj : devList) {
					System.out.println("inside loop1");
					double perHourBilling = devObj.getPcObj().getPerHourBilling();
					System.out.println("inside loop2");
					int Id = devObj.getdObj().getDeveloperId();
					System.out.println("inside loop3");
					DataEntryOperator deo = developerDao.getDeoObj(Id, month, year);
					System.out.println("inside loop4");
					System.out.println(deo.getFullDay());
					System.out.println("inside loop5");
					bill += (deo.getFullDay() * 9 + deo.getHalfDay() * 4.5) * perHourBilling;

					count++;
				}
			}

			return bill;
		} catch (Exception e) {
			e.printStackTrace();
			;
		}
		return 0;
	}

	/* (non-Javadoc)
	 * @see com.iris.get19.pbms.service.AdminService#getDevAllocation()
	 */
	@Override
	public List<DevAllocation> getDevAllocation() {
		return projectDao.getDevAllocation();
	}

	/* (non-Javadoc)
	 * @see com.iris.get19.pbms.service.AdminService#getFilterDevelopers()
	 */
	@Override
	public List<Developer> getFilterDevelopers() {
		// TODO Auto-generated method stub
		return developerDao.getFilteredDeveloper();
	}

	/* (non-Javadoc)
	 * @see com.iris.get19.pbms.service.AdminService#delProjConfig(int)
	 */
	@Override
	public boolean delProjConfig(int id) {
		return projectDao.delProjectConfig(id);
	}

	/* (non-Javadoc)
	 * @see com.iris.get19.pbms.service.AdminService#getProjectConfig(int)
	 */
	@Override
	public ProjectConfiguration getProjectConfig(int id) {
		return projectDao.getProjectConfig(id);
	}

	/* (non-Javadoc)
	 * @see com.iris.get19.pbms.service.AdminService#updateProjectConfig(com.iris.get19.pbms.dao.model.ProjectConfiguration)
	 */
	@Override
	public boolean updateProjectConfig(ProjectConfiguration projObj) {
		return projectDao.updateProjectConfig(projObj);
	}

}
