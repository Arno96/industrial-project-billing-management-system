package com.iris.get19.pbms.dao;

import java.util.List;



import com.iris.get19.pbms.dao.model.DeveloperRole;


public interface RoleDao {

	List<DeveloperRole> getAllRole();
	DeveloperRole getRoleById(int id);
}
