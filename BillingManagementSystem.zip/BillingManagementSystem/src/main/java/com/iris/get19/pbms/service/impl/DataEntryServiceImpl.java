package com.iris.get19.pbms.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.iris.get19.pbms.dao.DeveloperDao;
import com.iris.get19.pbms.dao.ProjectDao;
import com.iris.get19.pbms.dao.model.DataEntryOperator;
import com.iris.get19.pbms.dao.model.Developer;
import com.iris.get19.pbms.dao.model.ProjectConfiguration;
import com.iris.get19.pbms.service.DataEntryService;


@Component
@Repository(value="dataEntryService")
@Transactional
public class DataEntryServiceImpl implements DataEntryService {

	@Autowired
	private DeveloperDao developerDao;
	
	@Override
	public boolean setDevAttendance(DataEntryOperator deoObj) {
		return developerDao.setAttendance(deoObj);
		
		
	}

}
