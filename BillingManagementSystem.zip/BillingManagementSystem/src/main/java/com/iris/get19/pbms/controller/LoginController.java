package com.iris.get19.pbms.controller;



import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.iris.get19.pbms.dao.model.Developer;
import com.iris.get19.pbms.service.AdminService;

@RestController
public class LoginController {
	
	@Autowired 
	private AdminService adminService;
	@Autowired
	HttpSession session;
	
	@CrossOrigin(origins="http://localhost:4200")
	@RequestMapping(value="/validateRole",method=RequestMethod.POST)
	public ResponseEntity<?> validateRole(@RequestBody Developer dev) {
		Developer devObj = adminService.getDeveloper(dev);
		if(devObj==null){
			return new ResponseEntity<String>("null",HttpStatus.UNAUTHORIZED);
		} 
		else {
			session.setAttribute("userObj",devObj );
			return new ResponseEntity<Developer>(devObj,HttpStatus.OK);
		}
	}
}
